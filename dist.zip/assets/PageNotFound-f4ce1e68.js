import{j as n}from"./index-f52ca885.js";function t(){return n.jsx("div",{children:n.jsx("h1",{children:"Page not found 😢"})})}export{t as default};
