const t="_product_1ijzm_1",o={product:t};export{o as s};
